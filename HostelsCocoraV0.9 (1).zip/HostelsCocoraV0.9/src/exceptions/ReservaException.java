package exceptions;

public class ReservaException extends Exception {

	public ReservaException(String mensaje) {
		super(mensaje);
	}
}
