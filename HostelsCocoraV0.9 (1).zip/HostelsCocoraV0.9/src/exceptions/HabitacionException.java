package exceptions;

public class HabitacionException extends Exception {

	public HabitacionException(String mensaje) {
		super(mensaje);
	}
}
