package exceptions;

public class CamaException extends Exception {

	public CamaException(String mensaje) {
		super(mensaje);
	}
}
