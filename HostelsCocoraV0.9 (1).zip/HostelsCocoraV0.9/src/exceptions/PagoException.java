package exceptions;

public class PagoException extends Exception {

	public PagoException(String mensaje) {
		super(mensaje);
	}
}
