package model;

public enum Tipo {
	INDIVIDUAL, DOBLE;

}
