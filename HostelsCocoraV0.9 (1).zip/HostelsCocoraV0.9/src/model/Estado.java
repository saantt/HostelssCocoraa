package model;

public enum Estado {
	MANTENIMIENTO, EN_OPERACION;

}
