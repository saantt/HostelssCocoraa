package model;

public enum TipoPago {
	EN_LINEA, PAGO_HOTEL;

}
