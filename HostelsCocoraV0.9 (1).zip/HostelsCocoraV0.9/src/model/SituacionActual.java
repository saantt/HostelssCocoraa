package model;

public enum SituacionActual {
	DISPONIBLE, RESERVADA;
}
